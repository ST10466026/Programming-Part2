﻿using System;
using System.Collections.Generic;
using CybersecurityChatbot.Models;

namespace CybersecurityChatbot.Services
{
    public class ChatService
    {
        private static readonly Random _rng = new Random();
        private readonly List<ChatTopic> _topics;

        public static readonly List<string> UnknownResponses = new List<string>
        {
            "🤔 I'm not sure I understand. Could you try rephrasing that?",
            "Hmm, I didn't quite catch that. Try typing a topic name or 'help' for the full list.",
            "I'm still learning! Could you rephrase that, or type 'help' to see available topics?",
            "That one has me stumped. Try keywords like 'phishing', 'password', or 'malware'."
        };

        public static readonly List<string> EmptyInputResponses = new List<string>
        {
            "Looks like you didn't type anything. Give it another go! 😊",
            "Don't be shy — type a question or topic and I'll help!",
            "I need a little input from you. What would you like to know?"
        };

        public static readonly List<string> Acknowledgements = new List<string>
        {
            "Great question! Here's what you need to know:",
            "Absolutely! Let me break that down for you:",
            "Sure thing! Here's some important information:",
            "Good thinking — cybersecurity awareness starts here:"
        };

        public ChatService()
        {
            _topics = BuildTopics();
        }

        public string GetResponse(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return GetRandom(EmptyInputResponses);

            var lower = input.ToLower().Trim();

            if (lower.Contains("about me") || lower.Contains("who are you") || lower.Contains("what are you"))
                return AboutBot();

            foreach (var topic in _topics)
                foreach (var kw in topic.Keywords)
                    if (lower.Contains(kw))
                        return $"{GetRandom(Acknowledgements)}\n\n{GetRandom(new List<string>(topic.Responses))}";

            return GetRandom(UnknownResponses);
        }

        public List<ChatTopic> GetAllTopics() => _topics;

        private static string GetRandom(List<string> list)
        {
            if (list == null || list.Count == 0) return string.Empty;
            return list[_rng.Next(list.Count)];
        }

        private string AboutBot() =>
            "🤖 ABOUT ME\n\nI'm the Cybersecurity Awareness Bot — a C# WPF application built to educate users about online safety.\n\n" +
            "Type 'help' to see all 18 topics, or just ask me anything about cybersecurity!";

        private List<ChatTopic> BuildTopics() => new List<ChatTopic>
        {
            new ChatTopic
            {
                Name = "Password Safety", Emoji = "🔑",
                Keywords = new[] { "password", "passwords", "passphrase", "credentials" },
                Responses = new[]
                {
                    "🔑 PASSWORD SAFETY\n\nWeak passwords are the #1 way hackers get in.\n\n✅ Strong Password Rules:\n• At least 12–16 characters\n• Mix of UPPERCASE, lowercase, numbers & symbols\n• No real words, names, or birthdays\n• Unique — never reuse across sites\n\n🛡️ Best Practices:\n• Use a Password Manager (Bitwarden is free)\n• Enable 2FA on every account\n• Change passwords after any suspected breach\n\n❌ Avoid: 'password123', 'qwerty', your name or pet's name.\n\n💡 Visit haveibeenpwned.com to check if your email was in a breach.",
                    "🔑 PASSWORD SAFETY — Pro Tips\n\nDid you know 81% of data breaches involve weak or stolen passwords?\n\n🧪 Password Manager Benefits:\n• Generates unique strong passwords for every site\n• You only remember ONE master password\n• Alerts you if your password appears in known breaches\n\nFree: Bitwarden, KeePass | Paid: 1Password, LastPass\n\n⚠️ Never share your password with anyone — not IT, not your bank."
                }
            },
            new ChatTopic
            {
                Name = "Phishing Awareness", Emoji = "🎣",
                Keywords = new[] { "phishing", "phish", "fake email", "email scam", "spoofed" },
                Responses = new[]
                {
                    "🎣 PHISHING AWARENESS\n\nPhishing is the #1 cause of data breaches worldwide.\n\n🔴 Warning Signs:\n• Urgency: 'Your account will be closed!'\n• Sender address doesn't match the company\n• Hover over links — the real URL looks wrong\n• Poor grammar or generic greetings\n\n✅ Stay Safe:\n• Never click links in unexpected emails\n• Type website addresses directly in your browser\n• When in doubt, call the company on their OFFICIAL number\n• Report phishing emails to your IT team",
                    "🎣 PHISHING — Types to Know\n\nOver 3.4 billion phishing emails are sent daily!\n\n📧 Types:\n• Email Phishing — mass fake emails\n• Spear Phishing — targeted attacks using your real name\n• Smishing — phishing via SMS\n• Vishing — phishing via phone call\n\n🛡️ Golden Rule: Legitimate organisations NEVER ask for your password or OTP via email or phone."
                }
            },
            new ChatTopic
            {
                Name = "Safe Browsing", Emoji = "🌐",
                Keywords = new[] { "safe browsing", "browsing", "browser", "website", "https", "vpn", "web" },
                Responses = new[]
                {
                    "🌐 SAFE BROWSING\n\nEvery website you visit can track or infect you. Browse smart.\n\n✅ Essentials:\n• Always look for HTTPS 🔒 in the URL bar\n• Keep your browser updated\n• Use an ad blocker (uBlock Origin — free & excellent)\n• Only download from official sources\n\n🛡️ Privacy Upgrades:\n• VPN — encrypts traffic and hides your IP\n• Privacy browser: Firefox or Brave\n• Search engine: DuckDuckGo\n\n⚠️ Never access banking on public Wi-Fi without a VPN"
                }
            },
            new ChatTopic
            {
                Name = "Malware Protection", Emoji = "🦠",
                Keywords = new[] { "malware", "virus", "trojan", "spyware", "adware", "worm", "keylogger", "antivirus" },
                Responses = new[]
                {
                    "🦠 MALWARE PROTECTION\n\nMalware is any software designed to harm, spy on, or take over your device.\n\n🔴 Common Types:\n• Virus — attaches to files and spreads\n• Worm — self-replicates across networks\n• Trojan — disguised as legitimate software\n• Spyware — secretly monitors you\n• Keylogger — records everything you type\n\n✅ Protection:\n• Keep OS and apps updated\n• Use reputable antivirus software\n• Download only from official sources\n• Never plug in unknown USB drives"
                }
            },
            new ChatTopic
            {
                Name = "Social Engineering", Emoji = "🎭",
                Keywords = new[] { "social engineering", "social", "manipulation", "pretexting", "baiting", "tailgating" },
                Responses = new[]
                {
                    "🎭 SOCIAL ENGINEERING — Hacking Humans\n\nAttackers exploit psychology, not just technology. YOU are the target.\n\n🔴 Common Tactics:\n• Pretexting — 'Hi, I'm from IT. I need your password.'\n• Baiting — infected USB left hoping you'll plug it in\n• Tailgating — following someone through a secure door\n• Urgency and Fear — 'Act now or your account is deleted!'\n\n✅ Defence:\n• Always verify identity before sharing any info\n• Call back on the OFFICIAL number — not the one they gave\n• When in doubt, escalate to your manager or security team"
                }
            },
            new ChatTopic
            {
                Name = "Two-Factor Authentication", Emoji = "🔐",
                Keywords = new[] { "two-factor", "2fa", "mfa", "multi-factor", "authentication", "otp", "one-time" },
                Responses = new[]
                {
                    "🔐 TWO-FACTOR AUTHENTICATION (2FA)\n\nEven if a hacker steals your password, 2FA stops them getting in.\n\n📱 How It Works:\n'Something you KNOW' (password) + 'Something you HAVE' (phone code) = Much stronger security\n\n✅ 2FA Types (Best to Weakest):\n1. Hardware Key (YubiKey)\n2. Authenticator App (Google Authenticator, Authy)\n3. Email code\n4. SMS code — still better than nothing\n\n🔒 Enable 2FA on: Email, Banking, Social Media, Work accounts\n\n💡 Never share your OTP with anyone — ever."
                }
            },
            new ChatTopic
            {
                Name = "Data Privacy", Emoji = "🔏",
                Keywords = new[] { "privacy", "private", "data privacy", "personal data", "tracking", "data collection" },
                Responses = new[]
                {
                    "🔏 DATA PRIVACY\n\nYour personal data is extremely valuable. Companies and criminals both want it.\n\n🔴 Risks:\n• Data brokers selling your info to advertisers or scammers\n• Social media oversharing\n• Apps collecting far more data than they need\n\n✅ Protect Yourself:\n• Review privacy settings on ALL social media\n• Audit app permissions — Location, Camera, Microphone\n• Use a private email alias for sign-ups (SimpleLogin is free)\n• Use Signal for private messaging\n\n💡 Golden Rule: If a service is free, YOUR data is the product."
                }
            },
            new ChatTopic
            {
                Name = "Ransomware Prevention", Emoji = "🔒",
                Keywords = new[] { "ransomware", "ransom", "encrypted files", "locked files" },
                Responses = new[]
                {
                    "🔒 RANSOMWARE PREVENTION\n\nRansomware encrypts all your files and demands payment to unlock them.\n\n🔴 How It Spreads:\n• Malicious email attachments\n• Infected downloads\n• Outdated software vulnerabilities\n• Unknown USB drives\n\n✅ Prevention:\n• Follow the 3-2-1 Backup Rule: 3 copies, 2 different media, 1 offsite\n• Keep your OS and all apps updated\n• Never open unexpected attachments\n\n⚠️ If Hit:\n• Do NOT pay the ransom\n• Disconnect from the network IMMEDIATELY\n• Contact a cybersecurity professional"
                }
            },
            new ChatTopic
            {
                Name = "Wi-Fi Security", Emoji = "📶",
                Keywords = new[] { "wifi", "wi-fi", "wireless", "public wifi", "hotspot", "router", "network" },
                Responses = new[]
                {
                    "📶 WI-FI SECURITY\n\nYour Wi-Fi network can be a serious vulnerability if not secured.\n\n🏠 Home Router:\n• Change the default admin username AND password\n• Use WPA3 or WPA2 encryption (never WEP)\n• Keep router firmware updated\n• Create a separate guest network for visitors and IoT devices\n\n☕ Public Wi-Fi:\n• Never access banking or sensitive accounts on public Wi-Fi\n• Always use a VPN on public networks\n• Disable auto-connect to open networks on your device"
                }
            },
            new ChatTopic
            {
                Name = "Social Media Safety", Emoji = "📱",
                Keywords = new[] { "social media", "facebook", "instagram", "twitter", "tiktok", "linkedin", "online profile" },
                Responses = new[]
                {
                    "📱 SOCIAL MEDIA SAFETY\n\nYour profiles reveal far more about you than you realise.\n\n🔴 Oversharing Risks:\n• Birthday + school + pet name = security question answers for hackers\n• Posting your location tells criminals when you're away\n• Photos can contain GPS metadata revealing your address\n\n✅ Best Practices:\n• Set personal accounts to PRIVATE\n• Never accept friend requests from strangers\n• Enable 2FA on all social media accounts\n• Be wary of quizzes that ask personal questions — they harvest data\n• Regularly review which apps have access to your accounts"
                }
            },
            new ChatTopic
            {
                Name = "Software Updates", Emoji = "🔄",
                Keywords = new[] { "update", "updates", "patch", "patching", "software update", "outdated" },
                Responses = new[]
                {
                    "🔄 SOFTWARE UPDATES & PATCHING\n\nOutdated software is one of the most exploited attack vectors.\n\n💡 Why Updates Matter:\n• Patches fix known vulnerabilities that criminals actively exploit\n• The WannaCry ransomware exploited a Windows flaw that had a patch for months\n\n✅ Best Practices:\n• Enable automatic updates for your OS, browser, and apps\n• Don't ignore 'restart to finish updates' prompts\n• Update firmware on your router and IoT devices\n• Uninstall software you no longer use"
                }
            },
            new ChatTopic
            {
                Name = "Identity Theft Prevention", Emoji = "🪪",
                Keywords = new[] { "identity theft", "identity", "stolen identity", "id theft", "impersonation" },
                Responses = new[]
                {
                    "🪪 IDENTITY THEFT PREVENTION\n\nIdentity theft occurs when a criminal uses your personal info to commit fraud in your name.\n\n🔴 How It Happens:\n• Data breaches\n• Phishing emails\n• Physical theft of documents\n• Dumpster diving for discarded paperwork\n\n✅ Protect Yourself:\n• Shred sensitive documents before discarding\n• Monitor bank statements for unusual activity\n• Check your credit report regularly\n• Place a fraud alert if you suspect theft\n• Never carry your ID unless necessary"
                }
            },
            new ChatTopic
            {
                Name = "Email Security", Emoji = "📧",
                Keywords = new[] { "email", "email security", "spam", "email attachment", "inbox" },
                Responses = new[]
                {
                    "📧 EMAIL SECURITY\n\nEmail remains the #1 attack vector for cybercriminals.\n\n🔴 Common Threats:\n• Phishing — impersonating trusted brands\n• Malicious attachments (PDFs, Word docs, ZIP files)\n• Business Email Compromise — fake CEO requesting wire transfers\n\n✅ Stay Secure:\n• Enable spam filtering\n• Never open unexpected attachments — even from known senders\n• Check sender addresses carefully — not just the display name\n• Enable 2FA on your email account\n• Use a separate email for newsletters and sign-ups"
                }
            },
            new ChatTopic
            {
                Name = "Backup & Data Recovery", Emoji = "💾",
                Keywords = new[] { "backup", "backups", "data recovery", "restore", "cloud backup", "lost data" },
                Responses = new[]
                {
                    "💾 BACKUP & DATA RECOVERY\n\nIf ransomware strikes, a good backup is the difference between a bad day and a catastrophe.\n\n✅ The 3-2-1 Backup Rule:\n• 3 copies of your data\n• 2 different storage types (e.g. external drive + cloud)\n• 1 copy offsite (cloud counts)\n\n🛡️ Best Practices:\n• Automate your backups\n• Test backups regularly with a trial restore\n• Cloud options: Google Drive, OneDrive, Backblaze\n• Disconnect backup drives after use — ransomware can encrypt connected drives"
                }
            },
            new ChatTopic
            {
                Name = "Mobile Device Security", Emoji = "📲",
                Keywords = new[] { "mobile", "phone", "smartphone", "android", "iphone", "ios", "mobile security" },
                Responses = new[]
                {
                    "📲 MOBILE DEVICE SECURITY\n\nYour phone contains your contacts, banking, emails, and photos. Protect it.\n\n🔴 Mobile Threats:\n• Malicious apps from unofficial stores\n• Unsecured public Wi-Fi\n• SIM-swapping attacks\n• Physical theft\n\n✅ Best Practices:\n• Use a strong PIN, password, or biometric lock\n• Only download apps from official stores\n• Review app permissions — deny anything excessive\n• Enable remote wipe (Find My iPhone / Find My Device)\n• Keep the OS and apps updated\n• Be cautious of public chargers — use your own cable"
                }
            },
            new ChatTopic
            {
                Name = "IoT & Smart Home Security", Emoji = "🏠",
                Keywords = new[] { "iot", "smart home", "smart device", "smart tv", "alexa", "google home", "internet of things" },
                Responses = new[]
                {
                    "🏠 IoT & SMART HOME SECURITY\n\nYour smart TV, doorbell, and fridge are all computers — many have terrible security.\n\n🔴 IoT Risks:\n• Default passwords never changed\n• Rarely receive security updates\n• Can be entry points into your home network\n\n✅ Secure Your Smart Home:\n• Change the DEFAULT password on every device immediately\n• Create a separate IoT network on your router\n• Keep device firmware updated\n• Disable features you don't use\n• Cover camera lenses when not in use"
                }
            },
            new ChatTopic
            {
                Name = "Scam Awareness", Emoji = "⚠️",
                Keywords = new[] { "scam", "scams", "fraud", "fake", "lottery", "prize", "romance scam", "investment scam" },
                Responses = new[]
                {
                    "⚠️ SCAM AWARENESS\n\nScams are getting more convincing every year. They exploit urgency, trust, and emotion.\n\n🔴 Common Scam Types:\n• Lottery Scams — 'You've won! Just pay a small fee to claim.'\n• Romance Scams — fake relationships to extract money\n• Tech Support Scams — 'Your PC has a virus, call us now!'\n• Investment/Crypto Scams — promises of guaranteed huge returns\n• Impersonation Scams — criminals pretending to be your bank or SARS\n\n✅ Red Flags:\n• Requests for gift cards or cryptocurrency\n• Extreme urgency or fear tactics\n• Requests for your OTP, PIN, or personal details\n\n💡 If Scammed: Contact your bank immediately and report to SAPS Cybercrime Unit."
                }
            }
        };
    }
}