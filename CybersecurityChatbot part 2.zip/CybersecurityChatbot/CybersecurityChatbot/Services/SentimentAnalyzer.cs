﻿using System.Collections.Generic;

namespace CybersecurityChatbot.Services
{
    public enum Sentiment { Neutral, Happy, Sad, Angry, Stressed, Tired, Scared, Confused }

    public class SentimentAnalyzer
    {
        private static readonly Dictionary<Sentiment, List<string>> _keywords =
            new Dictionary<Sentiment, List<string>>
            {
                [Sentiment.Happy] = new List<string> { "happy", "great", "awesome", "good", "wonderful", "fantastic", "excited", "amazing", "love", "excellent", "brilliant", "glad" },
                [Sentiment.Sad] = new List<string> { "sad", "unhappy", "depressed", "miserable", "terrible", "bad", "awful", "upset", "down", "heartbroken" },
                [Sentiment.Angry] = new List<string> { "angry", "mad", "furious", "annoyed", "frustrated", "rage", "hate", "livid", "irritated" },
                [Sentiment.Stressed] = new List<string> { "stressed", "stress", "overwhelmed", "anxious", "worried", "nervous", "panic", "pressure", "tense" },
                [Sentiment.Tired] = new List<string> { "tired", "exhausted", "sleepy", "fatigue", "drained", "bored" },
                [Sentiment.Scared] = new List<string> { "scared", "afraid", "terrified", "hacked", "compromised", "attacked", "fear", "concerned" },
                [Sentiment.Confused] = new List<string> { "confused", "lost", "unsure", "not sure", "don't understand", "explain", "how does" }
            };

        private static readonly Dictionary<Sentiment, string> _responses =
            new Dictionary<Sentiment, string>
            {
                [Sentiment.Happy] = "😊 Love the positive energy! Let's keep you cyber-safe.",
                [Sentiment.Sad] = "💙 I'm sorry you're feeling down. I'll keep things simple and clear for you.",
                [Sentiment.Angry] = "😤 I understand your frustration! Let's tackle this together.",
                [Sentiment.Stressed] = "🧘 Take a breath — you're in the right place. I'll break everything down step by step.",
                [Sentiment.Tired] = "😴 No worries, I'll keep it short and simple.",
                [Sentiment.Scared] = "🛡️ It's okay to feel concerned — awareness is your first defence!",
                [Sentiment.Confused] = "🤔 Great that you're asking questions! Let me explain clearly.",
                [Sentiment.Neutral] = ""
            };

        public Sentiment Analyze(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return Sentiment.Neutral;
            var lower = input.ToLower();
            foreach (var kvp in _keywords)
                foreach (var kw in kvp.Value)
                    if (lower.Contains(kw))
                        return kvp.Key;
            return Sentiment.Neutral;
        }

        public string GetResponse(Sentiment s) =>
            _responses.TryGetValue(s, out var r) ? r : string.Empty;

        public string ToString(Sentiment s) => s.ToString().ToLower();
    }
}