﻿using System;
using System.Speech.Synthesis;
using System.Threading.Tasks;

namespace CybersecurityChatbot.Services
{
    public class AudioService : IDisposable
    {
        private SpeechSynthesizer _synth;
        private bool _enabled = true;

        public AudioService()
        {
            try
            {
                _synth = new SpeechSynthesizer();
                try { _synth.SelectVoice("Microsoft David Desktop"); }
                catch { /* use default voice */ }
                _synth.Rate = 2;
                _synth.Volume = 90;
            }
            catch
            {
                _enabled = false;
            }
        }

        public async Task PlayVoiceGreetingAsync()
        {
            await SpeakAsync("Hi there! Welcome to the Cybersecurity Awareness Bot. I am here to help you stay safe online. Please tell me your name.");
        }

        public async Task SpeakAsync(string text)
        {
            if (!_enabled || _synth == null || string.IsNullOrWhiteSpace(text)) return;
            try
            {
                var clean = System.Text.RegularExpressions.Regex.Replace(text, @"[^\u0000-\u007F\s]", "");
                var idx = clean.IndexOfAny(new[] { '.', '!', '?' });
                var spoken = idx > 0 ? clean.Substring(0, idx + 1).Trim()
                           : clean.Length > 100 ? clean.Substring(0, 100)
                           : clean;
                await Task.Run(() => _synth.SpeakAsync(spoken));
            }
            catch { /* non-critical */ }
        }

        public void Dispose() => _synth?.Dispose();
    }
}