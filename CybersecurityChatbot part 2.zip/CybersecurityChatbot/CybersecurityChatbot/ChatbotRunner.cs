﻿using System;
using System.Threading.Tasks;

namespace CybersecurityChatbot
{
    public static class ChatbotRunner
    {
        public static async Task Run()
        {
            while (true)
            {
                var userInput = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(userInput))
                {
                    Console.WriteLine("Please type something. I'm here to help!");
                    continue;
                }

                if (userInput.ToLower() == "exit")
                {
                    Console.WriteLine("Goodbye! Stay safe online!");
                    break;
                }

                if (userInput.ToLower() == "help")
                {
                    Console.WriteLine(ChatbotInitializer.GetTopicListText());
                    continue;
                }

                var response = ChatbotInitializer.ChatService.GetResponse(userInput);
                Console.WriteLine(response);
                await Task.CompletedTask;
            }
        }
    }
}