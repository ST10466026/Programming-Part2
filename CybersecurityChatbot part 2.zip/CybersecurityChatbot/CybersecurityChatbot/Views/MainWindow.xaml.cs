﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using CybersecurityChatbot.Models;
using CybersecurityChatbot.Services;

namespace CybersecurityChatbot.Views
{
    public partial class MainWindow : Window
    {
        private readonly AudioService _audioService;
        private readonly ChatService _chatService;
        private readonly MemoryService _memoryService;
        private readonly SentimentAnalyzer _sentimentAnalyzer;

        private enum State { AwaitingName, Active }
        private State _state = State.AwaitingName;

        private static readonly List<(string Emoji, string Key)> _topicDefs =
            new List<(string, string)>
        {
            ("🔑", "password"),
            ("🎣", "phishing"),
            ("🌐", "safe browsing"),
            ("🦠", "malware"),
            ("🎭", "social engineering"),
            ("🔐", "2fa"),
            ("🔏", "privacy"),
            ("🔒", "ransomware"),
            ("📶", "wifi"),
            ("📱", "social media"),
            ("🔄", "software updates"),
            ("🪪", "identity theft"),
            ("📧", "email security"),
            ("💾", "backup"),
            ("📲", "mobile security"),
            ("🏠", "iot smart home"),
            ("⚠️",  "scams"),
            ("🤖", "about me"),
        };

        public MainWindow()
        {
            InitializeComponent();
            _audioService = new AudioService();
            _chatService = new ChatService();
            _memoryService = new MemoryService();
            _sentimentAnalyzer = new SentimentAnalyzer();

            BuildTopicChips();
            Loaded += OnWindowLoaded;
        }

        private async void OnWindowLoaded(object sender, RoutedEventArgs e)
        {
            AppendBotMessage(AsciiArt.GetCyberSecurityLogo(), useMonospace: true);
            await Task.Delay(300);
            AppendBotMessage(
                "👋 Welcome to the Cybersecurity Awareness Bot!\n\n" +
                "I'm here to help you learn about online safety practices.\n\n" +
                "Before we begin — what's your name?");
            await _audioService.PlayVoiceGreetingAsync();
            UserInput.Focus();
        }

        private void BuildTopicChips()
        {
            var ti = System.Globalization.CultureInfo.CurrentCulture.TextInfo;
            foreach (var (emoji, key) in _topicDefs)
            {
                var btn = new Button
                {
                    Content = $"{emoji} {ti.ToTitleCase(key)}",
                    Style = (Style)FindResource("TopicChip"),
                    Tag = key
                };
                btn.Click += TopicChip_Click;
                TopicPanel.Children.Add(btn);
            }
        }

        // ── Input handling ───────────────────────────────────────────

        private async void BtnSend_Click(object sender, RoutedEventArgs e) => await ProcessInput();
        private async void UserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) await ProcessInput();
        }
        private async void TopicChip_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string key)
            {
                UserInput.Text = key;
                await ProcessInput();
            }
        }

        private async Task ProcessInput()
        {
            var raw = UserInput.Text?.Trim();
            UserInput.Clear();

            try
            {
                if (string.IsNullOrWhiteSpace(raw))
                {
                    var empty = ChatService.EmptyInputResponses;
                    AppendBotMessage(empty[new Random().Next(empty.Count)]);
                    return;
                }

                AppendUserMessage(raw);
                await ShowTypingDots();

                if (_state == State.AwaitingName)
                {
                    HandleNameInput(raw);
                    return;
                }

                await HandleActiveInput(raw);
            }
            catch (Exception ex)
            {
                AppendBotMessage($"⚠️ Something went wrong: {ex.Message}. Please try again.");
            }
        }

        private void HandleNameInput(string input)
        {
            if (input.Length > 50 || HasDigits(input))
            {
                AppendBotMessage("That doesn't look like a name. Please enter your first name:");
                return;
            }

            _memoryService.SetUser(input);
            _state = State.Active;

            var s = _memoryService.Session;
            AppendBotMessage(
                $"{s.TimeGreeting}, {s.UserName}! 👋\n\n" +
                "I'm here to help you learn about online safety practices.\n\n" +
                GetHelpText());

            _ = _audioService.SpeakAsync($"Welcome {s.UserName}! Let's learn about cybersecurity.");
            UpdateUI();
        }

        private async Task HandleActiveInput(string input)
        {
            var lower = input.ToLower().Trim();
            var name = _memoryService.Session.UserName;

            if (lower == "exit" || lower == "quit" || lower == "bye")
            {
                AppendBotMessage($"👋 Goodbye, {name}! Stay safe online! 🔒");
                _ = _audioService.SpeakAsync($"Goodbye {name}! Stay safe online!");
                await Task.Delay(1500);
                Application.Current.Shutdown();
                return;
            }

            if (lower == "help" || lower == "menu" || lower == "topics")
            {
                AppendBotMessage(GetHelpText());
                return;
            }

            if (lower.Contains("what do you remember") || lower == "memory")
            {
                AppendBotMessage(
                    $"🧠 Here's what I remember about you, {name}:\n\n" +
                    $"• {_memoryService.GetMemorySummary()}");
                return;
            }

            // Sentiment
            var sentiment = _sentimentAnalyzer.Analyze(lower);
            string prefix = string.Empty;
            if (sentiment != Sentiment.Neutral)
            {
                _memoryService.SetSentiment(_sentimentAnalyzer.ToString(sentiment));
                prefix = _sentimentAnalyzer.GetResponse(sentiment) + "\n\n";
                UpdateUI();
            }

            // Topic response
            var response = _chatService.GetResponse(input);

            // Record topic in memory
            foreach (var topic in _chatService.GetAllTopics())
                foreach (var kw in topic.Keywords)
                    if (lower.Contains(kw))
                    { _memoryService.RecordTopic(topic.Name); UpdateUI(); break; }

            AppendBotMessage(prefix + response);
            _ = _audioService.SpeakAsync(response);
        }

        // ── Chat rendering ───────────────────────────────────────────

        private void AppendBotMessage(string text, bool useMonospace = false)
        {
            var container = new Border
            {
                Margin = new Thickness(0, 5, 80, 5),
                Padding = new Thickness(14, 12, 14, 12),
                Background = new SolidColorBrush(Color.FromRgb(0x0C, 0x15, 0x25)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(0x00, 0xE5, 0xFF)),
                BorderThickness = new Thickness(3, 0, 0, 0),
                CornerRadius = new CornerRadius(0, 8, 8, 8)
            };
            container.Effect = new DropShadowEffect
            {
                Color = Color.FromRgb(0x00, 0xE5, 0xFF),
                BlurRadius = 10,
                ShadowDepth = 0,
                Opacity = 0.12
            };

            var sp = new StackPanel();
            sp.Children.Add(new TextBlock
            {
                Text = "🤖  CYBERBOT",
                Foreground = new SolidColorBrush(Color.FromRgb(0x00, 0xE5, 0xFF)),
                FontSize = 9.5,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 6)
            });
            sp.Children.Add(new TextBlock
            {
                Text = text,
                Foreground = new SolidColorBrush(Color.FromRgb(0xDD, 0xE3, 0xF0)),
                FontSize = useMonospace ? 10.5 : 13,
                FontFamily = useMonospace
                               ? new FontFamily("Consolas")
                               : new FontFamily("Segoe UI"),
                TextWrapping = TextWrapping.Wrap,
                LineHeight = useMonospace ? 16 : 22
            });
            sp.Children.Add(new TextBlock
            {
                Text = DateTime.Now.ToString("HH:mm"),
                Foreground = new SolidColorBrush(Color.FromRgb(0x7A, 0x84, 0x98)),
                FontSize = 9.5,
                Margin = new Thickness(0, 6, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Right
            });

            container.Child = sp;
            FadeIn(container);
        }

        private void AppendUserMessage(string text)
        {
            var name = _memoryService.Session.UserName;
            var container = new Border
            {
                Margin = new Thickness(80, 5, 0, 5),
                Padding = new Thickness(14, 12, 14, 12),
                Background = new SolidColorBrush(Color.FromRgb(0x08, 0x20, 0x14)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(0x00, 0xE6, 0x76)),
                BorderThickness = new Thickness(0, 0, 3, 0),
                CornerRadius = new CornerRadius(8, 0, 8, 8),
                HorizontalAlignment = HorizontalAlignment.Right
            };

            var sp = new StackPanel();
            sp.Children.Add(new TextBlock
            {
                Text = $"👤  {name}",
                Foreground = new SolidColorBrush(Color.FromRgb(0x00, 0xE6, 0x76)),
                FontSize = 9.5,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 6),
                HorizontalAlignment = HorizontalAlignment.Right
            });
            sp.Children.Add(new TextBlock
            {
                Text = text,
                Foreground = new SolidColorBrush(Color.FromRgb(0xDD, 0xE3, 0xF0)),
                FontSize = 13,
                TextWrapping = TextWrapping.Wrap,
                LineHeight = 22,
                HorizontalAlignment = HorizontalAlignment.Right
            });
            sp.Children.Add(new TextBlock
            {
                Text = DateTime.Now.ToString("HH:mm"),
                Foreground = new SolidColorBrush(Color.FromRgb(0x7A, 0x84, 0x98)),
                FontSize = 9.5,
                Margin = new Thickness(0, 6, 0, 0)
            });

            container.Child = sp;
            FadeIn(container);
        }

        private async Task ShowTypingDots()
        {
            var dots = new Border
            {
                Margin = new Thickness(0, 5, 80, 5),
                Padding = new Thickness(14, 10, 14, 10),  // ← fixed: was new Thickness(14, 10)
                Background = new SolidColorBrush(Color.FromRgb(0x0C, 0x15, 0x25)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(0x16, 0x20, 0x30)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8)
            };
            dots.Child = new TextBlock
            {
                Text = "typing  ●  ●  ●",
                Foreground = new SolidColorBrush(Color.FromRgb(0x7A, 0x84, 0x98)),
                FontSize = 11
            };
            ChatPanel.Children.Add(dots);
            ScrollBottom();
            await Task.Delay(650);
            ChatPanel.Children.Remove(dots);
        }

        private void FadeIn(UIElement el)
        {
            el.Opacity = 0;
            ChatPanel.Children.Add(el);
            ScrollBottom();
            el.BeginAnimation(UIElement.OpacityProperty,
                new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(220)));
        }

        private void ScrollBottom()
        {
            ChatScroll.UpdateLayout();
            ChatScroll.ScrollToEnd();
        }

        // ── Sidebar buttons ──────────────────────────────────────────

        private async void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ChatPanel.Children.Clear();
            AppendBotMessage(
                $"Chat cleared! What would you like to explore next, " +
                $"{_memoryService.Session.UserName}?\n\nType 'help' to see all topics.");
            await Task.CompletedTask;
        }

        private async void BtnHelp_Click(object sender, RoutedEventArgs e)
        {
            UserInput.Text = "help";
            await ProcessInput();
        }

        private async void BtnMemory_Click(object sender, RoutedEventArgs e)
        {
            UserInput.Text = "what do you remember";
            await ProcessInput();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                $"Are you sure you want to exit, {_memoryService.Session.UserName}?\n\nStay safe online! 🔒",
                "Cybersecurity Awareness Bot",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
                Application.Current.Shutdown();
        }

        // ── Helpers ──────────────────────────────────────────────────

        private void UpdateUI()
        {
            MemoryLabel.Text = "• " + _memoryService.GetMemorySummary().Replace("\n", "\n• ");
            if (_state == State.Active)
                StatusLabel.Text = $"Chatting with {_memoryService.Session.UserName}";
        }

        private string GetHelpText() =>
            "Here's what I can help you with:\n\n" +
            "  🔑  1.  Password Safety\n" +
            "  🎣  2.  Phishing Awareness\n" +
            "  🌐  3.  Safe Browsing\n" +
            "  🦠  4.  Malware Protection\n" +
            "  🎭  5.  Social Engineering\n" +
            "  🔐  6.  Two-Factor Authentication\n" +
            "  🔏  7.  Data Privacy\n" +
            "  🔒  8.  Ransomware Prevention\n" +
            "  📶  9.  Wi-Fi Security\n" +
            "  📱 10.  Social Media Safety\n" +
            "  🔄 11.  Software Updates\n" +
            "  🪪 12.  Identity Theft Prevention\n" +
            "  📧 13.  Email Security\n" +
            "  💾 14.  Backup & Data Recovery\n" +
            "  📲 15.  Mobile Device Security\n" +
            "  🏠 16.  IoT & Smart Home Security\n" +
            "  ⚠️ 17.  Scam Awareness\n" +
            "  🤖 18.  About Me\n\n" +
            "💡 Type a topic name, number, or just ask me anything!";

        private static bool HasDigits(string s)
        {
            foreach (char c in s)
                if (char.IsDigit(c)) return true;
            return false;
        }

        protected override void OnClosed(EventArgs e)
        {
            _audioService?.Dispose();
            base.OnClosed(e);
        }
    }
}