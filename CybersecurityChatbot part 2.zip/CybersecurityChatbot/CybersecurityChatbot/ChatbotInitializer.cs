﻿using System;
using CybersecurityChatbot.Services;
using CybersecurityChatbot.Models;

namespace CybersecurityChatbot
{
    public static class ChatbotInitializer
    {
        public static AudioService AudioService { get; private set; }
        public static ChatService ChatService { get; private set; }
        public static MemoryService MemoryService { get; private set; }
        public static UserSession CurrentUser => MemoryService?.Session;

        public static void InitialiseServices()
        {
            AudioService = new AudioService();
            ChatService = new ChatService();
            MemoryService = new MemoryService();
        }

        public static string GetTopicListText()
        {
            return string.Join("\n", new[]
            {
                "  🔑  Password Safety",
                "  🎣  Phishing Awareness",
                "  🌐  Safe Browsing",
                "  🦠  Malware Protection",
                "  🎭  Social Engineering",
                "  🔐  Two-Factor Authentication (2FA)",
                "  🔏  Data Privacy",
                "  🔒  Ransomware Prevention",
                "  📶  Wi-Fi Security",
                "  📱  Social Media Safety",
                "  🔄  Software Updates & Patching",
                "  🪪  Identity Theft Prevention",
                "  📧  Email Security",
                "  💾  Backup & Data Recovery",
                "  📲  Mobile Device Security",
                "  🏠  IoT & Smart Home Security",
                "  ⚠️  Scam Awareness",
                "  🤖  About Me"
            });
        }
    }
}